$(function() {
    for(var i=1; i <= 3; i++) {
        $( "#text" + i ).draggable();
    }
});